# Mmmm-So-Good-

Tracking Plan Link: 
1. Answer to Questions: https://docs.google.com/document/d/1iF0qUI-r_cmDwlcie4IkMJMvTH7VMs2-PGk8rJ7Lobk/edit
2. Dashboard: https://docs.google.com/spreadsheets/d/1FQbs8LkD9ATtehUzAzWPgGKhykSKG1Ri79Iq9q8JTOo/edit?usp=sharing

Testing Plan Link:
1. https://docs.google.com/document/d/1dIcD0e9hWUEQi8GAsCivHTMRRT6kfB2PBUSzCj7z_yc/edit

Link to app server: https://spelman-472-2017-3.appspot.com/_ah/api/helloworldendpoints/v1/sayHelloByName?name 

Link to UI: https://drive.google.com/drive/folders/0B_quynlzmtqfNm8tTmRCTjJBNDQ?usp=sharing

